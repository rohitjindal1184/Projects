//
//  PAWGetStartVC.h
//  lokay
//
//  Created by Rohit Jindal on 30/07/15.
//  Copyright (c) 2015 Parse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PAWWelcomeViewController.h"
@interface PAWGetStartVC : UIViewController
- (IBAction)getSatrt:(id)sender;

@end
