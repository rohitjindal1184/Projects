//
//  MapPinView.m
//  Lokay
//
//  Created by Rohit Jindal on 08/04/15.
//  Copyright (c) 2015 Parse. All rights reserved.
//

#import "MapPinView.h"

@implementation MapPinView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void)dealloc
{
	//[self removeObserver:nil forKeyPath:@"selected"];
	
}
@end
