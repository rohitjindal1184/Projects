//
//  MapPinView.h
//  Lokay
//
//  Created by Rohit Jindal on 08/04/15.
//  Copyright (c) 2015 Parse. All rights reserved.
//

#import <MapKit/MapKit.h>

@interface MapPinView : MKAnnotationView

@end
