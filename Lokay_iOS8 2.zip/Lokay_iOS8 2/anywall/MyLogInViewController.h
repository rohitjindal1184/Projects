//
//  MyLogInViewController.h
//  LogInAndSignUpDemo
//
//  Created by Mattieu Gamache-Asselin on 6/15/12.
//

@interface MyLogInViewController : PFLogInViewController

@end
