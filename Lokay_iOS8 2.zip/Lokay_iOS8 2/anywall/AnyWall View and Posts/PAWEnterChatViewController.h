//
//  PAWEnterChatViewController.h
//  LokayMe
//
//  Created by He Fei on 12/26/13.
//  Copyright (c) 2013 Parse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZBarSDK.h"
@interface PAWEnterChatViewController : UIViewController
{
	ZBarReaderViewController *reader;

}

@end
