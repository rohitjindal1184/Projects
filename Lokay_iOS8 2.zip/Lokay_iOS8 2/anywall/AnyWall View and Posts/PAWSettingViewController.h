//
//  PAWSettingViewController.h
//  lokay
//
//  Created by Rohit Jindal on 18/08/15.
//  Copyright (c) 2015 Parse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
@interface PAWSettingViewController : UIViewController<MFMailComposeViewControllerDelegate>

@end
