//
//  OverlayViewController.h
//  Lokay
//
//  Created by Rohit Jindal on 06/04/15.
//  Copyright (c) 2015 Parse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OverlayViewController : UIViewController

@end
