//
//  HTHorizontalSelectionListScrollView.m
//  HTHorizontalSelectionList Example
//
//  Created by Erik Ackermann on 9/15/14.
//  Copyright (c) 2014 Hightower. All rights reserved.
//

#import "HTHorizontalSelectionListScrollView.h"

@implementation HTHorizontalSelectionListScrollView

- (BOOL)touchesShouldCancelInContentView:(UIView *)view {
    return YES;
}

@end

// Copyright belongs to original author
// http://code4app.net (en) http://code4app.com (cn)
// From the most professional code share website: Code4App.net 
